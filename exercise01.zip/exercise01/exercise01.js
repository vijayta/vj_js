function compare(mary, john) {
  if(mary < john){
    alert("John is elder then Mary");
  } 
  else if(mary > john){
    alert("Mary is elder then John");
  }
  else{
    alert("Mary and John are on same age");
  }
}